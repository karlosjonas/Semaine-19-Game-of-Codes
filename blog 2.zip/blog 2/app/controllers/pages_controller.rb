class PagesController < ApplicationController
 

  def home
  	@les_articles = Article.page(params[:page]).per(5)
  	
  end

  def show
  	@le_article = Article.find(params[:id])	
  end
end
